package database_Back;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*******
 * 
 * @author Vaibhav(170032);
 * 
 * @version 1.01 2019-12-07
 * 
 */

public class GetEntries {

	public String getItem(String index, String rollNo) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3305/dbcsfinal?useSSL=false", "root",
				"vishu189");

		String topic_name = null;

		String ret = "Select * from student_data WHERE reg = '" + index + "' AND rollno = '" + rollNo + "';";

		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(ret);

		while (rs.next()) {
			topic_name = rs.getString("name");
		}

		return topic_name;
	}

	public String getfname(String index, String rollNo) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3305/dbcsfinal?useSSL=false", "root",
				"vishu189");

		String topic_name = null;

		String ret = "Select * from student_data WHERE reg = '" + index + "' AND rollno = '" + rollNo + "';";

		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(ret);

		while (rs.next()) {
			topic_name = rs.getString("fname");
		}

		return topic_name;
	}

	public String getmname(String index, String rollNo) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3305/dbcsfinal?useSSL=false", "root",
				"vishu189");

		String topic_name = null;

		String ret = "Select * from student_data WHERE reg = '" + index + "' AND rollno = '" + rollNo + "';";

		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(ret);

		while (rs.next()) {
			topic_name = rs.getString("mname");
		}

		return topic_name;
	}

	public String getcourse(String index, String rollNo) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3305/dbcsfinal?useSSL=false", "root",
				"vishu189");

		String topic_name = null;

		String ret = "Select * from student_data WHERE reg = '" + index + "' AND rollno = '" + rollNo + "';";

		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(ret);

		while (rs.next()) {
			topic_name = rs.getString("course");
		}

		return topic_name;
	}

	public String getyear(String index, String rollNo) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3305/dbcsfinal?useSSL=false", "root",
				"vishu189");

		String topic_name = null;

		String ret = "Select * from student_data WHERE reg = '" + index + "' AND rollno = '" + rollNo + "';";

		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(ret);

		while (rs.next()) {
			topic_name = rs.getString("year");
		}

		return topic_name;
	}

	public String getsem(String index, String rollNo) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3305/dbcsfinal?useSSL=false", "root",
				"vishu189");

		String topic_name = null;

		String ret = "Select * from student_data WHERE reg = '" + index + "' AND rollno = '" + rollNo + "';";

		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(ret);

		while (rs.next()) {
			topic_name = rs.getString("sem");
		}

		return topic_name;
	}

	public void updateTopic(String reg, String rollno, String name, String fname, String mname, String course,
			String year, String sem) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3305/dbcsfinal?useSSL=false", "root",
				"vishu189");

		String insert = "UPDATE student_data SET reg = '" + reg + "', rollno = '" + rollno + "', name = '" + name
				+ "', fname = '" + fname + "', mname = '" + mname + "', course = '" + course + "', sem = '" + sem
				+ "', year = '" + year + "';";
		Statement stat = conn.createStatement();
		stat.executeUpdate(insert);

	}

	public void removeTopic(String reg, String rollno) throws SQLException, ClassNotFoundException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3305/dbcsfinal?useSSL=false", "root",
				"vishu189");

		String insert = "DELETE FROM student_data where reg = '" + reg + "' AND rollno = '" + rollno + "';";
		Statement stat = conn.createStatement();
		stat.executeUpdate(insert);
	}

}
