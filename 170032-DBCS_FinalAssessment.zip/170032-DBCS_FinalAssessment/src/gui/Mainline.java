package gui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/*******
 * 
 * @author Vaibhav(170032);
 * 
 * @version 1.01 2019-12-07
 * 
 */

public class Mainline extends Application {

	public UserInterface UI;

	@Override
	public void start(Stage theStage) {
		theStage.setTitle("Student Registration System");
		Pane thePane = new Pane();
		UI = new UserInterface(thePane);
		Scene theScene = new Scene(thePane, 600, 500);
		theStage.setScene(theScene);
		theStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
