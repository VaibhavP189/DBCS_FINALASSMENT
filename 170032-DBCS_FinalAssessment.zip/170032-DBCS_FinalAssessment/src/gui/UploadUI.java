package gui;

import java.sql.SQLException;

import database_Back.GetEntries;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.Window;

/*******
 * 
 * @author Vaibhav(170032);
 * 
 * @version 1.01 2019-12-07
 * 
 */

public class UploadUI {
	private Label lbl_heading = new Label("Student Registration");

	private Label lbl_no = new Label("Registration Number");
	private Label lbl_rollno = new Label("Roll No");
	private Label lbl_name = new Label("Student Name");
	private Label lbl_fname = new Label("Father Name");
	private Label lbl_mname = new Label("Mother Name");
	private Label lbl_course = new Label("Course");
	private Label lbl_sem = new Label("Semester");
	private Label lbl_year = new Label("Year");

	private TextField txt_reg = new TextField();
	private TextField txt_rollno = new TextField();
	private TextField txt_name = new TextField();
	private TextField txt_fname = new TextField();
	private TextField txt_mname = new TextField();
	private TextField txt_course = new TextField();
	private TextField txt_year = new TextField();
	private TextField txt_sem = new TextField();

	private Button btn_Modify = new Button("Modify Entry");

	protected Window theStage;

	public UploadUI uploadUI;

	GetEntries ge = new GetEntries();

	Stage win = new Stage();
	Pane winpane = new Pane();
	selectEntry se = new selectEntry(winpane, win);

	public UploadUI(Pane uploadPane, Stage thisStage) {

		setupLabelUI(lbl_heading, "Arial", 30, 50, Pos.BASELINE_CENTER, 200, 20);
		lbl_heading.setFont(Font.font("Arial", FontWeight.BOLD, 20));

		setupLabelUI(lbl_no, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 80);
		setupLabelUI(lbl_rollno, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 120);
		setupLabelUI(lbl_name, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 160);
		setupLabelUI(lbl_fname, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 200);
		setupLabelUI(lbl_mname, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 240);
		setupLabelUI(lbl_course, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 280);
		setupLabelUI(lbl_sem, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 320);
		setupLabelUI(lbl_year, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 360);

		setupButtonUI(btn_Modify, "Arial", 15, 50, Pos.BASELINE_CENTER, 200, 425);

		setupTextUI(txt_reg, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 75, true);
		setupTextUI(txt_rollno, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 115, true);
		setupTextUI(txt_name, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 155, true);
		setupTextUI(txt_fname, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 195, true);
		setupTextUI(txt_mname, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 235, true);
		setupTextUI(txt_course, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 275, true);
		setupTextUI(txt_sem, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 315, true);
		setupTextUI(txt_year, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 355, true);

		String name = null;
		try {
			name = ge.getItem(se.txt_reg1.getText().toString(), se.txt_rollno1.getText().toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String fname = null;
		try {
			fname = ge.getfname(se.txt_reg1.getText().toString(), se.txt_rollno1.getText().toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String mname = null;
		try {
			mname = ge.getmname(se.txt_reg1.getText().toString(), se.txt_rollno1.getText().toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String course = null;
		try {
			course = ge.getcourse(se.txt_reg1.getText().toString(), se.txt_rollno1.getText().toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String year = null;
		try {
			year = ge.getyear(se.txt_reg1.getText().toString(), se.txt_rollno1.getText().toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sem = null;
		try {
			sem = ge.getsem(se.txt_reg1.getText().toString(), se.txt_rollno1.getText().toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		txt_reg.setText(se.txt_reg1.getText().toString());
		txt_rollno.setText(se.txt_rollno1.getText().toString());
		txt_name.setText(name);
		txt_fname.setText(fname);
		txt_mname.setText(mname);
		txt_course.setText(course);
		txt_year.setText(year);
		txt_sem.setText(sem);

		btn_Modify.setOnAction(e -> {
			try {
				uploadWindow();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});

		uploadPane.getChildren().addAll(lbl_heading, txt_reg, lbl_no, lbl_rollno, lbl_name, lbl_fname, lbl_mname,
				lbl_year, lbl_course, lbl_sem, txt_rollno, txt_name, txt_fname, txt_mname, txt_sem, txt_year,
				txt_course, btn_Modify);
	}

	private void uploadWindow() throws ClassNotFoundException, SQLException {

		System.out.println(se.txt_reg1.getText().toString());
		System.out.println(se.txt_rollno1.getText().toString());

		String reg = null;
		String rollno = null;
		String name = null;
		String fname = null;
		String mname = null;
		String course = null;
		String year = null;
		String sem = null;

		if (!txt_reg.getText().toString().isEmpty()) {
			reg = txt_reg.getText().toString();
		}
		if (!txt_rollno.getText().toString().isEmpty()) {
			rollno = txt_rollno.getText().toString();
		}
		if (!txt_name.getText().toString().isEmpty()) {
			name = txt_name.getText().toString();
		}
		if (!txt_fname.getText().toString().isEmpty()) {
			fname = txt_fname.getText().toString();
		}
		if (!txt_mname.getText().toString().isEmpty()) {
			mname = txt_mname.getText().toString();
		}
		if (!txt_course.getText().toString().isEmpty()) {
			course = txt_course.getText().toString();
		}
		if (!txt_sem.getText().toString().isEmpty()) {
			sem = txt_sem.getText().toString();
		}
		if (!txt_year.getText().toString().isEmpty()) {
			year = txt_year.getText().toString();
		}

		ge.updateTopic(reg, rollno, name, fname, mname, course, year, sem);

	}

	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupTextUI(TextField t, String ff, double f, double w, double d, Pos p, double x, double y,
			boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}


}
